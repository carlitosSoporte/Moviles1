
package institucion;

public class Parqueadero {
    
    
    //atributos de objeto
    String NumeroPlaca;
    String Fecha;
    
    
    //atributo de clase
    static int valor = 1200;
}
