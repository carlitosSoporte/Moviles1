
package minicalculadora;

public class Resta extends Operacion{

    public Resta(double Numero1, double Numero2) {
        super(Numero1, Numero2);
        this.setOperacionMatematica(2);
    }
    
    
}
