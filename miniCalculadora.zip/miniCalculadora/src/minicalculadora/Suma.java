
package minicalculadora;

public class Suma extends Operacion{


    public Suma( double Numero1, double Numero2) {
        super(Numero1, Numero2);
        this.setOperacionMatematica(1);
    }

        
}
