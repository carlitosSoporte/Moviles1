
package minicalculadora;

public class Division extends Operacion {

    public Division(double Numero1, double Numero2) {
        super(Numero1, Numero2);
        this.setOperacionMatematica(4);
    }
    
}
