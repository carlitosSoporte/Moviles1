
package minicalculadora;

public class Multiplicacion extends Operacion {

    public Multiplicacion(double Numero1, double Numero2) {
        super(Numero1, Numero2);
        this.setOperacionMatematica(3);
    }
    
}
